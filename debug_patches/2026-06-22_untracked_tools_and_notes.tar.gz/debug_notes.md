# Debug Notes

## Current Goal

Continue debugging `Isaac-Marl-Platoon-HAPPO-v0` play/training so the HAPPO-controlled platoon leader actually moves forward instead of staying near zero velocity.

## Context

- Workspace: `/home/cnc/SSD_1T/xzw/IsaacLab-main`
- Task: `Isaac-Marl-Platoon-HAPPO-v0`
- Main run/checkpoint inspected:
  - `logs/rsl_rl/platoon_happo/2026-06-16_20-54-42/model_final.pt`
- Relevant files:
  - `source/my_exts/marl_platoon/tasks/platoon/config.py`
  - `source/my_exts/marl_platoon/wrappers.py`
  - `source/my_exts/marl_platoon/algorithms/router.py`
  - `source/my_exts/marl_platoon/algorithms/happo/runner.py`
  - `source/my_exts/marl_platoon/algorithms/happo/actor.py`
  - `Melodic_wheeltec_robot_src_250707/src/turn_on_wheeltec_robot/urdf/senior_4wd_bs_robot.urdf`

## Latest Symptom

Long training after speed/logging changes showed unstable learning:

- RSL log around iteration `20117/3020000` reported `Episode_Termination/reset_on_bad_ori = 1.0000`.
- HAPPO update reported very large critic values, e.g. `value_loss ~= 1.84e9` and `critic_grad_norm ~= 9.07e7`.
- Latest CSV tail from `logs/rsl_rl/platoon_happo/2026-06-17_23-42-42/platoon_metrics.csv` showed:
  - command speed around `0.89-0.91 m/s`
  - leader speed often negative, around `-0.61` to `-0.78 m/s`
  - speed absolute error around `0.95-0.99`
  - physical cost around `18-20`
  - attack mode `cagan`, attack objective clipped at `20.0`
  - shield trigger rate near `1.0`

Interpretation: the task is running, but the training distribution has become too aggressive and numerically unstable.

Before the wheel-axis adapter, play log showed:

- `Loaded task-local HAPPO state and enabled deterministic HAPPO play mode.`
- `[Platoon HAPPO] action override active: joint_actions=(1, 6, 4), flat_action_dim=24`
- `command_vel[0]` around `0.796 m/s`
- `actual_vel[0]` near zero
- `leader_motion` reward near zero
- Carb GPU warning appeared, but it is likely unrelated performance noise.

After adding the URDF wheel-axis adapter, the leader no longer stays near zero velocity, but the current checkpoint still drives too slowly:

- step 20: `actual_vel[0].x = 0.150 m/s`
- step 80: `actual_vel[0].x = 0.108 m/s`
- step 140: `actual_vel[0].x = 0.129 m/s`
- command remains about `0.796 m/s`

## Findings

- HAPPO action override path is active.
- The newer checkpoint `2026-06-16_20-54-42/model_final.pt` contains `platoon_happo_state`.
- Older inspected checkpoint `2026-05-26_19-30-03/model_final.pt` did not contain `platoon_happo_state`, so use the exact run path when debugging.
- The `senior_4wd_bs_robot.urdf` has opposite wheel joint axes:
  - left wheels use axis `0 -1 0`
  - right wheels use axis `0 1 0`
- Forward driving likely requires a signed left/right wheel pattern, not identical signs for all four wheels.
- Deterministic HAPPO actor output for the leader in the inspected checkpoint was small and mixed/same-sign, for example approximately:
  - `[-0.08, -0.21, -0.11, -0.12]`
- This can cancel translation or produce weak wheel commands, explaining near-zero chassis velocity.
- IsaacLab action term joint order is `['lb_wheel_joint', 'lf_wheel_joint', 'rb_wheel_joint', 'rf_wheel_joint']`.
- With this URDF, the correct adapter sign pattern is `[1, 1, -1, -1]` for each agent.
- After the adapter, the leader processed action at step 20 became approximately `[-0.93, -2.57, 1.44, 1.45]`, and actual wheel velocities closely followed the processed targets.
- Therefore actuator tracking is working; the remaining speed gap is mainly because the current checkpoint's HAPPO raw action magnitude is small, not because IsaacLab is ignoring velocity targets.
- The post-change instability is not caused by `Mean reward: 0.00`; that value is expected for the frozen outer PPO path. The real red flags are `reset_on_bad_ori=1.0`, negative leader velocity, and exploding HAPPO critic loss.
- Likely causes of the instability:
  - `TARGET_SPEED_RANGE=(0.8, 1.0)` and `WHEEL_ACTION_SCALE=20.0` were a large jump from the previous setup.
  - `happo_action_clip=1.0` allows saturation to `20 rad/s` wheel targets.
  - `happo_action_warmup_updates=0` starts full HAPPO/attack/shield control immediately, with no low-speed stabilization period.
  - `enable_attack=True`, `attack_mode=cagan`, and medium attack budgets make early learning harsher.
  - `termination_bad_heading_chain()` terminates whenever any robot heading x component is below `0`, so short yaw flips or attack-induced spins make `reset_on_bad_ori` dominate.

## Changes Made

- In `config.py`, `reward_leader_velocity_matching()` debug print was delayed until `common_step_counter >= 20`.
- That debug now prints:
  - command velocity
  - actual root velocity
  - leader raw wheel action
  - leader processed wheel action
  - leader wheel joint velocity
  - error mean and reward mean
- In `wrappers.py`, added optional HAPPO action diagnostics when `happo_log_level == "debug"` and action steps reach 20:
  - raw leader HAPPO action
  - clipped leader HAPPO action
  - final env leader action after pipeline postprocessing/shield
- In `wrappers.py`, added `happo_urdf_wheel_sign_adapter` at the final env-action出口, after pipeline attacker/shield postprocessing.
  - The adapter resolves wheel joint names and applies `[1, 1, -1, -1]` for the senior 4WD URDF.
  - This keeps task-internal HAPPO/shield semantics as "same sign = same driving direction" and only converts at the IsaacLab joint target boundary.
- In `config.py`, declared env-side HAPPO fields including `happo_log_level`, `happo_action_clip`, `happo_action_warmup_updates`, and `happo_urdf_wheel_sign_adapter`.
- In `config.py`, leader motion debug now prints at steps `20, 80, 140, ...` instead of only once.
- Follow-up training cleanup:
  - `PlatoonHAPPOEnvCfg.__post_init__()` now explicitly sets `self.algorithm.happo_urdf_wheel_sign_adapter = True`.
  - Wrapper startup log now prints `wheel_axis_adapter=True/False` so new training logs prove which action convention was used.
  - No temporary post-adapter action gain was added; retraining should learn under the corrected wheel-axis convention directly.
- Speed/data logging update for paper experiments:
  - `TARGET_SPEED_RANGE` is now `(0.8, 1.0)` m/s.
  - Wheel action scale is now `20.0`, wheel velocity limit is now `20.0 rad/s`, and `happo_action_clip` is now `1.0`.
  - `happo_action_warmup_updates` is now `0`, so training starts with task-local HAPPO actions instead of executing random outer PPO warmup actions.
  - Wrapper clamps final flat actions immediately before `env.step()`; this also bounds attacker/shield postprocessed actions.
  - `PlatoonAlgorithmRouter` writes `platoon_metrics.csv` in each run directory with update/time, command/actual speed, spacing/lateral errors, reward terms, HAPPO losses, attack stats, physical costs, Teacher metrics, and shield stats.
  - CSV now also includes `termination_time_out` and `termination_reset_on_bad_ori` for automatic stage promotion checks.
  - Added `scripts/tools/plot_platoon_metrics.py` to generate paper-style plots from the CSV.
  - Added `scripts/tools/check_platoon_stage.py` to check promotion criteria from recent CSV rows.
  - Added `scripts/tools/run_platoon_curriculum.sh` to run staged curriculum training automatically:
    1. `stage1_stable`: low-speed, no attack.
    2. `stage2_speedup`: higher speed, no attack.
    3. `stage3_easy_attack`: easy profile attack.
    4. `stage4_cagan`: medium CA-GAN attack.

## Verification

Syntax check passed:

```bash
python3 -m py_compile source/my_exts/marl_platoon/tasks/platoon/config.py source/my_exts/marl_platoon/wrappers.py
```

Latest syntax check also passed:

```bash
python3 -m py_compile source/my_exts/marl_platoon/wrappers.py source/my_exts/marl_platoon/algorithms/router.py source/my_exts/marl_platoon/tasks/platoon/config.py source/my_exts/marl_platoon/tasks/__init__.py source/my_exts/marl_platoon/tasks/platoon/agents.py scripts/tools/plot_platoon_metrics.py
```

Short train smoke test passed:

```bash
PYTHONPATH=/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_rl:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_tasks:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/my_exts:/home/cnc/SSD_1T/xzw/isaac-sim/extscache/omni.usd.libs-1.0.1+69cbf6ad.lx64.r.cp311 /home/cnc/SSD_1T/xzw/isaac-sim/python.sh scripts/reinforcement_learning/rsl_rl/train.py --task Isaac-Marl-Platoon-HAPPO-v0 --num_envs 1 --headless --max_iterations 1 --kit_args="--/rtx/verifyDriverVersion/enabled=false"
```

Key output:

- startup line includes `wheel_axis_adapter=True, action_clip=1.0, warmup_updates=0`
- step 20 action manager raw action is bounded, e.g. `[-0.017, 1.0, 1.0, -1.0]`
- CSV was written to `logs/rsl_rl/platoon_happo/2026-06-17_23-38-51/platoon_metrics.csv`
- `python3` currently lacks `matplotlib`; plotting script now reports `python3 -m pip install pandas matplotlib` if dependencies are missing.

Play verification:

```bash
PYTHONPATH=/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_rl:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_tasks:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/my_exts:/home/cnc/SSD_1T/xzw/isaac-sim/extscache/omni.usd.libs-1.0.1+69cbf6ad.lx64.r.cp311 /home/cnc/SSD_1T/xzw/isaac-sim/python.sh scripts/reinforcement_learning/rsl_rl/play.py --task Isaac-Marl-Platoon-HAPPO-v0 --num_envs 1 --checkpoint /home/cnc/SSD_1T/xzw/IsaacLab-main/logs/rsl_rl/platoon_happo/2026-06-16_20-54-42/model_final.pt --headless --enable_cameras --video --video_length 150 --kit_args="--/rtx/verifyDriverVersion/enabled=false"
```

Key output after adapter:

- `[Platoon HAPPO] URDF wheel-axis adapter active: signs=[[1.0, 1.0, -1.0, -1.0], ...]`
- step 20: `actual_vel[0]=[0.1501, -0.0006]`, reward mean `0.124`
- step 80: `actual_vel[0]=[0.1077, 0.0037]`, reward mean `0.093`
- step 140: `actual_vel[0]=[0.1285, -0.0036]`, reward mean `0.108`

## Next Steps

Parameter recommendation after comparing the stable 3000-iteration run with the unstable high-speed run:

- Do not train from scratch with `TARGET_SPEED_RANGE=(0.8, 1.0)`, `WHEEL_ACTION_SCALE=20.0`, `happo_action_clip=1.0`, `happo_action_warmup_updates=0`, and `medium+cagan` attack all at once.
- A better stable baseline is close to the old run but with the URDF wheel adapter:
  - `TARGET_SPEED_RANGE=(0.6, 0.8)`
  - `WHEEL_ACTION_SCALE=12.0` or at most `14.0`
  - `WHEEL_VELOCITY_LIMIT=12.0`
  - `happo_action_clip=0.4`
  - `happo_action_warmup_updates=10`
  - start with `enable_attack=False`
- After stable tracking, resume and increase in stages:
  - speed stage: `TARGET_SPEED_RANGE=(0.7, 0.9)`, `WHEEL_ACTION_SCALE=14.0`, `happo_action_clip=0.5`
  - easy attack stage: `enable_attack=True`, `attack_level=easy`, `attack_mode=profile`
  - full attack stage: `attack_level=medium`, `attack_mode=cagan`, only after `reset_on_bad_ori` is low and critic loss is finite/stable.
- Monitor promotion criteria in `platoon_metrics.csv`: positive `leader_speed_mean`, decreasing `speed_error_abs_mean`, non-diverging `gap_error_abs_mean`, low `reset_on_bad_ori`, finite `value_loss`, and bounded `critic_grad_norm`.

1. Keep the wheel-axis adapter enabled for this URDF.
2. Retrain or fine-tune HAPPO with the adapter enabled; the old checkpoint was trained under the wrong wheel sign convention and outputs weak actions.
3. If quick checkpoint salvage is needed, test a configurable post-adapter drive gain or higher `JointVelocityActionCfg.scale`, but treat that as a temporary diagnostic because it changes the action semantics.
4. For Hydra debug overrides, use env cfg path `algorithm.happo_log_level=debug`; `agent.platoon.happo_log_level=debug` does not affect the wrapper because the wrapper reads `env_cfg.algorithm`.
5. If retraining with adapter still cannot approach the `0.5-0.8 m/s` command, then inspect actuator limits/friction/contact settings. Current evidence does not point there because wheel targets and actual wheel velocities match closely.

Recommended retraining command:

```bash
PYTHONPATH=/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_rl:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_tasks:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/my_exts:/home/cnc/SSD_1T/xzw/isaac-sim/extscache/omni.usd.libs-1.0.1+69cbf6ad.lx64.r.cp311 /home/cnc/SSD_1T/xzw/isaac-sim/python.sh scripts/reinforcement_learning/rsl_rl/train.py --task Isaac-Marl-Platoon-HAPPO-v0 --num_envs 2048 --headless --max_iterations 2000 --kit_args="--/rtx/verifyDriverVersion/enabled=false"
```

Expected startup line should include `wheel_axis_adapter=True`.

Recommended visualization command after training:

```bash
python3 scripts/tools/plot_platoon_metrics.py logs/rsl_rl/platoon_happo/<RUN_DIR>/platoon_metrics.csv --smooth 10
```

The script saves figures under `logs/rsl_rl/platoon_happo/<RUN_DIR>/figures/` and writes `summary.csv`.

One-click curriculum command:

```bash
scripts/tools/run_platoon_curriculum.sh
```

Optional resume from an existing stable run:

```bash
START_RUN=2026-06-17_17-34-19 START_CHECKPOINT=model_final.pt scripts/tools/run_platoon_curriculum.sh
```

2026-06-18 Hydra override fix:

- IsaacLab task configs are registered in Hydra under two top-level keys: `env` and `agent`.
- The curriculum script previously used bare overrides such as `commands.base_velocity.ranges.lin_vel_x=...`, `algorithm.happo_action_clip=...`, and `actions.joint_vel_1.scale=...`.
- That causes `Key 'commands' is not in struct` because `commands` is inside the environment config, not the Hydra root.
- Fixed `scripts/tools/run_platoon_curriculum.sh` so all environment overrides use `env.` prefixes:
  - `env.commands.base_velocity.ranges.lin_vel_x=[...]`
  - `env.algorithm.*`
  - `env.actions.joint_vel_*.scale=...`
- `bash -n scripts/tools/run_platoon_curriculum.sh` passes after the fix.
- The user-facing command is unchanged:

```bash
START_RUN=2026-06-17_17-34-19 START_CHECKPOINT=model_final.pt scripts/tools/run_platoon_curriculum.sh
```

2026-06-18 CUDA OOM fix and validation:

- Failure mode: `torch.OutOfMemoryError` occurred around HAPPO update 20 with `NUM_ENVS=4096`; RTX 3080 10GB had only about `40 MiB` free while IsaacSim plus PyTorch were active.
- Root cause: 4096 envs leaves too little headroom for task-local HAPPO updates. The old HAPPO runner also evaluated action log-probs on the full rollout batch when updating the sequential HAPPO factor.
- Fixes:
  - `scripts/tools/run_platoon_curriculum.sh` default `NUM_ENVS` changed from `4096` to `2048`.
  - Script now exports `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`.
  - Script now supports `STOP_AFTER_STAGE=stage1_stable` for real single-stage smoke tests.
  - HAPPO factor update now uses stored rollout old log-probs and computes new log-probs in chunks.
  - Added `happo_num_mini_batches=16` and `happo_factor_chunk_size=4096` to lower update-time memory peaks.
- Validation:
  - `python3 -m py_compile ...` and `bash -n scripts/tools/run_platoon_curriculum.sh` pass.
  - Real 3-iteration stage1 resume test passed with 2048 envs and wrote CSV/checkpoints:
    - run: `logs/rsl_rl/platoon_happo/2026-06-18_12-08-28_stage1_stable`
  - Real 22-iteration stage1 resume test passed with 2048 envs, reached HAPPO update 22, saved `model_final.pt`, and wrote 22 CSV rows:
    - run: `logs/rsl_rl/platoon_happo/2026-06-18_12-09-33_stage1_stable`
    - final observed speed: about `13712 steps/s`
    - final `value_loss` about `5.68`, `critic_grad_norm` about `14.64`
    - post-run GPU memory returned to about `857 MiB` used / `9148 MiB` free.
- Behavioral note: resuming from `2026-06-17_17-34-19/model_final.pt` still gives high `termination_reset_on_bad_ori` in the short validation window because that checkpoint was trained before the corrected wheel-axis/action curriculum. This is now a policy-quality issue, not an execution/OOM issue. For clean curriculum training, prefer starting stage1 from scratch unless checkpoint salvage is specifically needed.

Useful environment variables:

- `NUM_ENVS=2048`
- `STAGE1_ITERS=3000`
- `STAGE2_ITERS=2000`
- `STAGE3_ITERS=2000`
- `STAGE4_ITERS=3000`
- `AUTO_PROMOTE=0` to run each stage without automatic PASS/FAIL gating.

The curriculum script stops after a stage if `check_platoon_stage.py` detects negative/weak leader speed, high speed error, high `termination_reset_on_bad_ori`, exploding `value_loss`, or exploding `critic_grad_norm`.

2026-06-18 stage4 instability diagnosis and fix:

- Live run inspected:
  - command: `--num_envs 32 --run_name stage4_cagan --resume --load_run 2026-06-18_16-16-14_stage3_easy_attack`
  - it was intentionally/explicitly running with 32 envs, so speed around `400 steps/s` is expected and much slower than the RTX 3080 2048-env validation.
- Latest curriculum results before the fix:
  - stage1 `2026-06-18_13-09-14_stage1_stable`: PASS
  - stage2 `2026-06-18_14-58-28_stage2_speedup`: PASS
  - stage3 `2026-06-18_16-16-14_stage3_easy_attack`: PASS
  - stage4 `2026-06-18_17-31-46_stage4_cagan`: bad despite old checker saying PASS.
- Old stage4 last-window summary:
  - `leader_speed_mean ~= 0.11`
  - `speed_error_abs_mean ~= 0.80`
  - `gap_error_max_abs ~= 8.19`
  - `termination_reset_on_bad_ori ~= 0.31`
  - `shield_trigger_rate ~= 0.99`
  - attack was still in `profile` warmup, not true CA-GAN yet.
- Key cause: stage4 jumped to `0.8-1.0 m/s + medium attack`, and medium `max_fdi_acc=1.5` was applied directly to normalized actions with `happo_action_clip=0.6`. The action perturbation was larger than the action range, so it randomized/saturated actions before the policy was robust.
- Current bad stage4 run was stopped to avoid wasting GPU time; the stage3 checkpoint remains available.
- Fixes made:
  - Added env/agent config fields `max_fdi_pos`, `max_fdi_acc`, and `max_dos_rate`.
  - Router now treats negative values as “use attack preset” and uses nonnegative values as explicit overrides.
  - Curriculum changed from 4 stages to 5 stages:
    1. `stage1_stable`
    2. `stage2_speedup`
    3. `stage3_easy_attack` with reduced action attack: `max_fdi_acc=0.20`, `max_dos_rate=0.03`
    4. `stage4_medium_profile`: `speed=[0.75,0.9]`, `attack_mode=profile`, `max_fdi_acc=0.25`, `max_dos_rate=0.05`
    5. `stage5_cagan`: `speed=[0.8,0.95]`, `attack_mode=cagan`, `max_fdi_acc=0.30`, `max_dos_rate=0.06`, `attack_curriculum_warmup_updates=500`
  - `run_platoon_curriculum.sh` now warns when `NUM_ENVS < 512`.
  - `run_platoon_curriculum.sh` default `NUM_ENVS` is restored to `2048`; a local/default value of `32` was the direct reason for the observed `~400 steps/s` speed.
  - `run_platoon_curriculum.sh` now supports `START_STAGE` so training can resume directly from a later curriculum stage.
  - `check_platoon_stage.py` now checks speed, speed error, gap mean/max, lateral error, bad heading reset, shield trigger rate, value loss, and critic grad norm.
  - Old bad stage4 CSV now correctly FAILs with:
    - `leader_speed_mean < 0.25`
    - `speed_error_abs_mean > 0.7`
    - `gap_error_max_abs > 4.0`
    - `shield_trigger_rate > 0.97`
    - `termination_reset_on_bad_ori > 0.25`
- Verification:
  - `python3 -m py_compile ...` passed.
  - `bash -n scripts/tools/run_platoon_curriculum.sh` passed.
  - New checker still passes stage1/stage2/stage3 historical CSVs and fails the bad stage4 CSV.
  - Real smoke test passed for new `stage4_medium_profile` overrides using stage3 checkpoint:
    - run: `logs/rsl_rl/platoon_happo/2026-06-18_17-41-59_stage4_medium_profile_smoke`
    - loaded `2026-06-18_16-16-14_stage3_easy_attack/model_final.pt`
    - ran 3 HAPPO updates and saved `model_final.pt`
    - CSV confirms `attack_max_fdi_acc=0.25` and `attack_max_dos_rate=0.05`.
    - post-run GPU memory returned to about `855 MiB` used / `9151 MiB` free.

Recommended resume from the good stage3 checkpoint into the new gentler stage4:

```bash
cd /home/cnc/SSD_1T/xzw/IsaacLab-main
START_STAGE=stage4_medium_profile START_RUN=2026-06-18_16-16-14_stage3_easy_attack START_CHECKPOINT=model_final.pt scripts/tools/run_platoon_curriculum.sh
```

For full retraining from scratch, use:

```bash
cd /home/cnc/SSD_1T/xzw/IsaacLab-main
scripts/tools/run_platoon_curriculum.sh
```

2026-06-19 stage5_cagan checkpoint confirmation:

- Run inspected: `logs/rsl_rl/platoon_happo/2026-06-18_19-12-27_stage5_cagan`.
- CSV has 3000 rows, update column `1..3000`; RSL checkpoint number maps approximately as `model_N.pt -> csv update N - 8996`.
- `model_final.pt` is bad and should not be used for qualitative demos:
  - last-window `leader_speed_mean ~= 0.09`
  - `termination_reset_on_bad_ori = 1.0`
  - `value_loss ~= 3.16e6`, `critic_grad_norm ~= 2.64e5`
  - debug play showed raw leader action around `[-8.1, -13.8, 2.1, 6.8]`, clipped/saturated, and actual leader speed near zero.
- `model_10950.pt` is a valuable stable checkpoint:
  - around csv update `1954`, local metrics are healthy: `leader_speed_mean ~= 0.50`, `speed_error_abs_mean ~= 0.38`, `gap_error_abs_mean ~= 0.35`, `lateral_error_abs_mean ~= 0.19`, `termination_reset_on_bad_ori = 0`, `value_loss ~= 2.5`.
  - 50-row practical rolling-window ranking put the best stable band around RSL iter `10905..10914`, so `model_10950.pt` sits on the same stable plateau.
  - short play with training-consistent overrides (`happo_action_clip=0.6`, wheel action scale `14.0`, command speed `[0.8,0.95]`) gave leader speeds:
    - step 20: `0.730 m/s`
    - step 80: `0.604 m/s`
    - step 140: `0.608 m/s`
  - raw leader action was around `[-1.05, -0.91, -1.23, -0.97]`, clipped to `-0.6`, then wheel-axis adapted to `[-0.6, -0.6, 0.6, 0.6]`; processed wheel targets were `[-8.4, -8.4, 8.4, 8.4]`.
- `model_best.pt` is not a symlink/copy of `model_10950.pt`:
  - `model_best.pt` size/hash differs from `model_10950.pt`.
  - short play with the same training-consistent overrides was very similar or slightly better at the first sample:
    - step 20: `0.762 m/s`
    - step 80: `0.602 m/s`
    - step 140: `0.613 m/s`
  - raw leader action was around `[-1.43, -1.50, -0.98, -0.57]`, clipped/wheel-axis adapted to a sane forward-drive pattern.
- Important play/eval caveat:
  - Plain `play.py --checkpoint ...` does not automatically replay the stage5 Hydra overrides saved in `params/env.yaml`.
  - Without explicit overrides, current source defaults use `happo_action_clip=1.0`, `WHEEL_ACTION_SCALE=20.0`, and `TARGET_SPEED_RANGE=(0.8,1.0)`, which differs from stage5 training (`clip=0.6`, action scale `14.0`, speed `[0.8,0.95]`) and can exaggerate saturation/lateral drift.
- Current interpretation:
  - The original "leader not moving" issue is resolved for good mid-stage checkpoints; it remains only for the collapsed final checkpoint.
  - The current qualitative issue is now "the platoon moves but one or more followers can drift laterally."
  - This matches CSV: the good window still has `lateral_error_abs_mean ~= 0.18..0.22`, so individual vehicles can visibly run toward the side even when leader speed and bad-heading resets are good.

Recommended play command for stable visual checks:

```bash
cd /home/cnc/SSD_1T/xzw/IsaacLab-main
CHECKPOINT=/home/cnc/SSD_1T/xzw/IsaacLab-main/logs/rsl_rl/platoon_happo/2026-06-18_19-12-27_stage5_cagan/model_10950.pt
PYTHONPATH=/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_rl:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/isaaclab_tasks:/home/cnc/SSD_1T/xzw/IsaacLab-main/source/my_exts:/home/cnc/SSD_1T/xzw/isaac-sim/extscache/omni.usd.libs-1.0.1+69cbf6ad.lx64.r.cp311 \
/home/cnc/SSD_1T/xzw/isaac-sim/python.sh scripts/reinforcement_learning/rsl_rl/play.py \
  --task Isaac-Marl-Platoon-HAPPO-v0 \
  --num_envs 1 \
  --checkpoint "$CHECKPOINT" \
  --kit_args="--/rtx/verifyDriverVersion/enabled=false" \
  env.algorithm.happo_action_clip=0.6 \
  env.commands.base_velocity.ranges.lin_vel_x=[0.8,0.95] \
  env.actions.joint_vel_1.scale=14.0 \
  env.actions.joint_vel_2.scale=14.0 \
  env.actions.joint_vel_3.scale=14.0 \
  env.actions.joint_vel_4.scale=14.0 \
  env.actions.joint_vel_5.scale=14.0 \
  env.actions.joint_vel_6.scale=14.0 \
  "env.viewer.eye=[8.0,-10.0,6.0]" \
  "env.viewer.lookat=[-2.5,0.0,0.4]"
```

Next debugging direction:

- Prefer `model_10950.pt` or `model_best.pt` for demos; avoid `model_final.pt`.
- For lateral drift, next code-level work should focus on:
  - increasing lateral/yaw/heading alignment terms, not just leader speed;
  - adding or strengthening action smoothness / action-rate / jerk penalties;
  - considering a follower lateral/yaw safety projection in the shield, because the current shield only handles longitudinal gap/brake/catch-up behavior;
  - adding eval metrics/video labels for per-robot lateral error so the drifting robot is identifiable instead of relying only on aggregate `lateral_error_abs_mean`.

2026-06-19 status clarification:

- Completed: confirmed the current `stage5_cagan` result, identified `model_10950.pt` and `model_best.pt` as usable stable checkpoints, verified them with training-consistent play overrides, and documented the required play command.
- Not yet completed: code-level changes for the remaining lateral drift issue. The next implementation pass should modify reward/shield/metrics around lateral and heading stability.

2026-06-19 lateral drift mitigation implemented:

- Files changed for the lateral-drift pass:
  - `source/my_exts/marl_platoon/tasks/platoon/config.py`
  - `source/my_exts/marl_platoon/algorithms/shield.py`
  - `source/my_exts/marl_platoon/algorithms/router.py`
  - `scripts/tools/check_platoon_stage.py`
  - `scripts/tools/plot_platoon_metrics.py`
- Reward changes:
  - `reward_lateral_penalty_hard()` now has a `0.05 m` dead-zone and a stronger quadratic penalty after `0.25 m` visible lateral drift.
  - Added `reward_lateral_velocity_penalty()` to penalize follower side-slip / lateral velocity mismatch.
  - Added `reward_heading_alignment_penalty()` to penalize yaw/heading disagreement between the platoon and between adjacent vehicles.
  - Reward weights changed:
    - `action_rate`: `-0.06 -> -0.10`
    - `lateral_correct`: `-1.5 -> -3.0`
    - new `lateral_velocity`: `-0.8`
    - new `heading_align`: `-2.0`
- Shield changes:
  - Existing shield only handled longitudinal gap/catch-up and did not steer a drifting follower back to the predecessor centerline.
  - Added bounded lateral differential correction before the URDF wheel-axis adapter:
    - `lateral_tol=0.08`
    - `lateral_crit=0.35`
    - `lateral_turn_gain=0.70`
    - `lateral_turn_clip=0.18`
    - `lateral_velocity_gain=0.25`
  - Corrected the shield action convention for this URDF/HAPPO path:
    - pre-adapter negative same-sign commands drive forward.
    - `brake_action` default changed to `0.0`.
    - `catchup_action` default changed to `-0.35`.
  - New shield stats:
    - `shield_lateral_rate`
    - `shield_lateral_critical_rate`
    - `shield_lateral_turn_mean`
- Metrics/checking changes:
  - CSV now logs `lateral_error_abs_max`, `lateral_worst_pair`, `lateral_pair_1_abs_mean` through `lateral_pair_5_abs_mean`.
  - CSV now logs `heading_error_abs_mean`, `heading_error_abs_max`, `pair_heading_error_abs_mean`, and `pair_heading_error_abs_max`.
  - CSV now logs reward terms for `lateral_correct`, `lateral_velocity`, `heading_align`, and `action_rate`.
  - `check_platoon_stage.py` now optionally gates on `lateral_error_abs_max` when the column exists.
  - `plot_platoon_metrics.py` now plots lateral pair errors, heading errors, and new shield lateral stats.
- Verification:
  - Syntax check passed:

```bash
python3 -m py_compile source/my_exts/marl_platoon/tasks/platoon/config.py source/my_exts/marl_platoon/algorithms/shield.py source/my_exts/marl_platoon/algorithms/router.py scripts/tools/check_platoon_stage.py scripts/tools/plot_platoon_metrics.py
```

  - Real one-iteration smoke test passed with `num_envs=1`, `happo_action_clip=0.6`, wheel scales `14.0`, and command speed `[0.8,0.95]`.
  - Smoke run: `logs/rsl_rl/platoon_happo/2026-06-19_03-00-13`.
  - Smoke output confirmed 14 reward terms are active, including `lateral_velocity` and `heading_align`.
  - Smoke CSV row confirmed new fields are written, e.g.:
    - `lateral_error_abs_max = 0.1317`
    - `lateral_worst_pair = 5`
    - `heading_error_abs_mean = 0.0519`
    - `pair_heading_error_abs_mean = 0.0841`
    - `shield_lateral_rate = 0.4375`
    - `shield_lateral_turn_mean = 0.1001`
  - Post-change `model_10950.pt` play validation passed for 250 steps using the stage5-compatible overrides (`happo_action_clip=0.6`, wheel scale `14.0`, speed `[0.8,0.95]`).
    - The run completed without shield/runtime errors.
    - Leader velocity samples stayed healthy: step 20 `0.730 m/s`, step 80 `0.604 m/s`, step 140 `0.608 m/s`, step 200 `0.624 m/s`.
    - New video path: `logs/rsl_rl/platoon_happo/2026-06-18_19-12-27_stage5_cagan/videos/play/rl-video-step-0.mp4`.
- Expected impact:
  - Existing `model_10950.pt` / `model_best.pt` can be played with the new shield projection, but the reward changes mainly affect retraining/fine-tuning.
  - For a clean evaluation, replay `model_10950.pt` with the same stage5 overrides and inspect whether the formerly drifting follower is corrected by the new lateral shield.
  - For best final behavior, resume/fine-tune from `model_10950.pt` or `model_best.pt` under the new lateral reward/shield settings rather than using `model_final.pt`.

2026-06-19 current result-data assessment:

- Meaningful performance data still comes from the completed 2026-06-18 curriculum/stage5 CSVs.
- The 2026-06-19 lateral-fix smoke run (`2026-06-19_03-00-13`) has only one CSV row, so it validates runtime wiring and new metrics, not final task performance.
- Stage progression from old data:
  - stage1 stable last50: `leader_speed_mean ~= 0.345`, `lateral_error_abs_mean ~= 0.048`, `reset_on_bad_ori = 0`.
  - stage2 speedup last50: `leader_speed_mean ~= 0.487`, `lateral_error_abs_mean ~= 0.168`, `reset_on_bad_ori = 0`.
  - stage3 easy attack last50: `leader_speed_mean ~= 0.411`, `lateral_error_abs_mean ~= 0.153`, `reset_on_bad_ori = 0`.
  - stage4 medium profile last50: `leader_speed_mean ~= 0.452`, `lateral_error_abs_mean ~= 0.228`, `reset_on_bad_ori = 0`.
- Stage5 stable checkpoint window (`model_10950.pt` vicinity) is usable but not perfect:
  - `command_speed_mean ~= 0.875`
  - `leader_speed_mean ~= 0.478`
  - `platoon_speed_mean ~= 0.487`
  - `speed_error_abs_mean ~= 0.388`
  - `gap_error_abs_mean ~= 0.352`
  - `lateral_error_abs_mean ~= 0.222`
  - `reset_on_bad_ori = 0`
  - `value_loss ~= 2.97`, `critic_grad_norm ~= 6.96`
  - Interpretation: stable, moves forward, no heading-reset collapse, but still only tracks about 55% of commanded speed and has visible lateral drift.
- Best stable 50-row window around RSL iter `10910` is slightly better laterally:
  - `leader_speed_mean ~= 0.478`
  - `speed_error_abs_mean ~= 0.390`
  - `gap_error_abs_mean ~= 0.353`
  - `lateral_error_abs_mean ~= 0.199`
  - `reset_on_bad_ori = 0`
  - `value_loss ~= 3.06`
- Stage5 final checkpoint is a failed endpoint:
  - last50 `leader_speed_mean ~= 0.091`
  - `reset_on_bad_ori = 1.0`
  - `value_loss ~= 3.16e6`
  - `critic_grad_norm ~= 2.64e5`
  - `leader_action_abs_mean ~= 11.3`
  - Interpretation: CA-GAN late-stage training destabilized the policy/critic; do not use `model_final.pt`.
- Overall assessment:
  - Current best usable result is good enough for qualitative demonstration using `model_10950.pt` or `model_best.pt`.
  - It is not yet a fully successful final experiment for a paper-quality claim because command speed tracking remains weak (`~0.48` actual vs `~0.875` command) and lateral drift remains visible (`~0.20-0.22 m` mean lateral error in the stable attack windows).
  - The new lateral reward/shield changes are the right next fix, but need a fine-tune/resume run before claiming data-level improvement.

Recommended next run after lateral fixes:

- Do not restart from scratch first.
- Do not resume from `model_final.pt`; it is collapsed.
- Start a short lateral-fix fine-tune from:
  - `logs/rsl_rl/platoon_happo/2026-06-18_19-12-27_stage5_cagan/model_10950.pt`
- Revised judgment after reviewing the proposed command:
  - The principle is correct: first stabilize lateral behavior at lower speed, with no attack or only light attack, before returning to medium CA-GAN.
  - Use a smaller `num_envs` first (`64`, or `32` if needed) to reduce RTX 3080 10GB OOM risk.
  - However, `attack_level=light` is not currently a supported preset; valid values are `off`, `easy`, `medium`, `hard`. Unknown values fall back to `medium`, so do not use `attack_level=light`.
  - `happo_action_clip=0.3` with wheel scale `10.0` is very conservative. It may reduce lateral drift, but it may also make speed tracking too weak. If speed collapses below `0.35-0.40 m/s`, use `happo_action_clip=0.35-0.4` and wheel scale `10-12`.
- Recommended first fine-tune budget: `300-500` iterations, then inspect the new CSV before running longer.
- Main success criterion for the fine-tune:
  - keep `leader_speed_mean >= 0.35` for the low-speed lateral stabilization pass, then recover to `>=0.45` before going back to high speed/attack
  - reduce `lateral_error_abs_mean` from `~0.20-0.22` toward `<0.15`
  - keep `termination_reset_on_bad_ori = 0`
  - keep `value_loss` and `critic_grad_norm` finite and non-exploding.

2026-06-20 latest run assessment:

- Latest run inspected: `logs/rsl_rl/platoon_happo/2026-06-19_14-39-00_stage5_cagan_light_from_10950`.
- It ran 800 CSV rows / updates and produced checkpoints `model_10950.pt` through `model_11749.pt`.
- The run used:
  - `num_envs=64`
  - command speed `[0.6,0.8]`
  - `happo_action_clip=0.3`
  - wheel scale `10.0`
  - `attack_level=light`, `attack_mode=cagan`, `max_fdi_acc=0.1`, `max_dos_rate=0.02`
- Important config issue:
  - `attack_level=light` is still not a supported preset in the code.
  - Because of fallback behavior, the run logged `attack_max_fdi_pos=5.0`, i.e. medium-style observation FDI amplitude, despite the run name saying light.
  - If light attack is desired, either add a real `light` preset in `router.py` or use `attack_level=easy` plus explicit `max_fdi_pos=1.0`, `max_fdi_acc=0.05..0.10`, `max_dos_rate=0.01..0.02`.
- Latest run result:
  - Final last50 fails `stage5_cagan` check.
  - Final last50:
    - `leader_speed_mean ~= 0.154`
    - `speed_error_abs_mean ~= 0.581`
    - `gap_error_abs_mean ~= 0.238`
    - `lateral_error_abs_mean ~= 0.428`
    - `lateral_error_abs_max ~= 1.78`
    - `reset_on_bad_ori = 0`
    - `shield_trigger_rate ~= 0.999`
    - `shield_lateral_rate ~= 0.910`
    - `shield_lateral_critical_rate ~= 0.581`
    - `value_loss ~= 24.6`, `critic_grad_norm ~= 36.4`
  - Interpretation: no catastrophic reset/critic explosion, but the platoon is too slow and lateral drift gets worse over training.
- Best 50-row window in this latest run is around updates `228..277`, nearest checkpoint `model_11200.pt`:
  - `leader_speed_mean ~= 0.151`
  - `speed_error_abs_mean ~= 0.575`
  - `lateral_error_abs_mean ~= 0.163`
  - `lateral_error_abs_max ~= 0.87`
  - `value_loss ~= 0.73`
  - `critic_grad_norm ~= 1.24`
  - It improves lateral mean compared with old stage5 (`~0.20-0.22`) but sacrifices too much speed.
- Main problems:
  - `happo_action_clip=0.3` and wheel scale `10.0` are too conservative for this checkpoint. Effective wheel command is capped at about `3 rad/s`, so leader speed collapses to about `0.15 m/s`.
  - Lateral shield is triggering almost all the time; with low action clip, the lateral correction consumes too much of the available action range and fights forward drive.
  - Unsupported `attack_level=light` leaves `max_fdi_pos=5.0`, so the run is not actually a clean light-attack experiment.
- Recommended improvement:
  1. Do not continue this latest run as final.
  2. For a no-attack lateral stabilization pass, retry from original `2026-06-18_19-12-27_stage5_cagan/model_10950.pt` with:
     - `happo_action_clip=0.4`
     - wheel scale `12.0`
     - speed `[0.6,0.8]`
     - `enable_attack=false`
     - reduce shield lateral override: `lateral_turn_gain=0.45`, `lateral_turn_clip=0.10`, `lateral_tol=0.12`.
  3. If adding light CA-GAN later, use `attack_level=easy` or implement `light`; also explicitly lower `max_fdi_pos` to `1.0`.
- Play recommendation:
  - To inspect the latest run's best lateral-but-slow point, use `2026-06-19_14-39-00_stage5_cagan_light_from_10950/model_11200.pt`.
  - For the best qualitative moving demo, still prefer the older `2026-06-18_19-12-27_stage5_cagan/model_10950.pt` or `model_best.pt`.

2026-06-20 why the latest training is still poor:

- The run combined several stabilizing choices that together removed too much control authority.
- `happo_action_clip=0.3` and wheel scale `10.0` cap env wheel targets at about `3 rad/s`; the previously usable checkpoint needed roughly `8.4 rad/s` (`clip=0.6`, scale `14.0`) to move around `0.6 m/s`.
- The new lateral shield then consumes a large fraction of that small action budget:
  - `shield_trigger_rate ~= 0.999`
  - `shield_lateral_rate ~= 0.91`
  - `shield_lateral_critical_rate ~= 0.58`
  - `lateral_turn_clip=0.18`, which is 60% of `happo_action_clip=0.3`.
  - Result: the shield is almost always steering/braking/correcting, leaving little forward drive.
- `attack_level=light` is unsupported and falls back to medium preset behavior for unspecified fields:
  - CSV shows `attack_max_fdi_pos=5.0`.
  - Even with `max_fdi_acc=0.1` and `max_dos_rate=0.02`, observation FDI is not actually light.
- There is still an action semantics mismatch in the HAPPO wrapper:
  - The env executes clipped/postprocessed/shielded/adapted actions.
  - The HAPPO buffer still stores the original policy `pending_actions`.
  - With `clip=0.3`, policy outputs around `leader_action_abs_mean ~= 1.0`, but the env executes no more than `0.3`.
  - This mismatch is much worse than in the old `clip=0.6` run and can make the policy update chase actions the robot never actually executed.
- The latest run is therefore not simply "needs more iterations"; it is under-actuated, over-shielded, not truly light-attack, and training on action data that differs from executed actions.
- Highest-priority fixes before another long run:
  1. Use enough action authority for forward drive: try `happo_action_clip=0.4`, wheel scale `12.0`.
  2. Weaken lateral shield relative to the clip: `lateral_turn_gain=0.35-0.45`, `lateral_turn_clip=0.08-0.10`, `lateral_tol=0.12`.
  3. Disable attack for the first lateral pass, or use a real supported light setting: `attack_level=easy`, `max_fdi_pos=1.0`, `max_fdi_acc=0.05-0.10`, `max_dos_rate=0.01-0.02`.
  4. Fix the wrapper/router so HAPPO stores the executed clipped/postprocessed action, or avoid very small clips until that mismatch is fixed.

2026-06-20 suitable configuration applied:

- Code/config changes made for the next run:
  - Default task speed changed from `TARGET_SPEED_RANGE=(0.8,1.0)` to `(0.6,0.8)`.
  - Default wheel action scale changed from `20.0` to `12.0`.
  - Default HAPPO action clip changed from `1.0` to `0.4`.
  - HAPPO task entry now defaults to `enable_attack=false`, `attack_level=off`, `attack_mode=profile`.
  - Legacy `AttackCfg` now defaults to disabled/light budgets: `max_fdi_pos=1.0`, `max_fdi_acc=0.10`, `max_dos_rate=0.02`.
  - Safety shield lateral correction weakened to avoid taking over the small action budget:
    - `lateral_tol=0.12`
    - `lateral_crit=0.45`
    - `lateral_turn_gain=0.45`
    - `lateral_turn_clip=0.10`
    - `lateral_velocity_gain=0.15`
  - `router.py` now supports a real `attack_level=light` preset:
    - `max_fdi_pos=1.0`
    - `max_fdi_acc=0.10`
    - `max_dos_rate=0.02`
  - Unknown `attack_level` now raises `ValueError` instead of silently falling back to medium.
  - `run_platoon_curriculum.sh` default `NUM_ENVS` changed to `64`, warns above `128`, and final `stage5_cagan` is now light CA-GAN:
    - speed `[0.7,0.85]`
    - `happo_action_clip=0.45`
    - wheel scale `12.0`
    - `attack_level=light`, `max_fdi_pos=1.0`, `max_fdi_acc=0.10`, `max_dos_rate=0.02`
    - default `STAGE5_ITERS=1000`
- Verification:
  - `python3 -m py_compile source/my_exts/marl_platoon/tasks/platoon/config.py source/my_exts/marl_platoon/tasks/platoon/agents.py source/my_exts/marl_platoon/tasks/__init__.py source/my_exts/marl_platoon/algorithms/router.py` passed.
  - `bash -n scripts/tools/run_platoon_curriculum.sh` passed.
- Next run should not continue the poor `2026-06-19_14-39-00_stage5_cagan_light_from_10950` result as final.
- Start from the older useful checkpoint:
  - `logs/rsl_rl/platoon_happo/2026-06-18_19-12-27_stage5_cagan/model_10950.pt`
- Recommended immediate run:
  - run name: `stage5_lateral_ft_v2`
  - `num_envs=64`
  - `enable_attack=false`
  - `happo_action_clip=0.4`
  - command speed `[0.6,0.8]`
  - wheel scale `12.0`
  - budget `300-500` iterations first, then inspect CSV before longer training.

2026-06-22 current modification inventory:

- `git diff --name-only` currently shows 16 tracked modified files:
  - `scripts/reinforcement_learning/rsl_rl/train.py`
  - `source/my_exts/marl_platoon/algorithms/attacker.py`
  - `source/my_exts/marl_platoon/algorithms/happo/actor.py`
  - `source/my_exts/marl_platoon/algorithms/happo/runner.py`
  - `source/my_exts/marl_platoon/algorithms/pipeline.py`
  - `source/my_exts/marl_platoon/algorithms/router.py`
  - `source/my_exts/marl_platoon/algorithms/shield.py`
  - `source/my_exts/marl_platoon/algorithms/student.py`
  - `source/my_exts/marl_platoon/algorithms/teacher.py`
  - `source/my_exts/marl_platoon/smoke_test_harl_adapter.py`
  - `source/my_exts/marl_platoon/tasks/__init__.py`
  - `source/my_exts/marl_platoon/tasks/platoon/agents.py`
  - `source/my_exts/marl_platoon/tasks/platoon/attacks.py`
  - `source/my_exts/marl_platoon/tasks/platoon/config.py`
  - `source/my_exts/marl_platoon/tasks/platoon/teacher.py`
  - `source/my_exts/marl_platoon/wrappers.py`
- Important untracked-but-edited paths:
  - `debug_notes.md`
  - `scripts/tools/run_platoon_curriculum.sh`
  - `scripts/tools/check_platoon_stage.py`
  - `scripts/tools/plot_platoon_metrics.py`
- Current key functional modifications to remember:
  - HAPPO/stage defaults are now lateral-stability-first: speed `[0.6,0.8]`, wheel scale `12.0`, `happo_action_clip=0.4`, default attack off.
  - Real `attack_level=light` now exists in `router.py`; unknown attack levels now raise instead of falling back to medium.
  - Safety shield lateral correction has been weakened: `lateral_tol=0.12`, `lateral_crit=0.45`, `lateral_turn_gain=0.45`, `lateral_turn_clip=0.10`, `lateral_velocity_gain=0.15`.
  - Curriculum stage5 now uses light CA-GAN instead of medium CA-GAN and defaults to `NUM_ENVS=64`, `STAGE5_ITERS=1000`.
  - Metrics/check/plot tooling includes lateral max, per-pair lateral error, heading error, and shield lateral stats.
  - Wrapper/router/HAPPO code includes task-local checkpointing/inference support, URDF wheel-axis adapter handling, HAPPO metrics CSV logging, and CA-GAN/teacher/shield pipeline instrumentation.

## Restore Command For Future Chats

Tell Codex:

```text
请先读取 /home/cnc/SSD_1T/xzw/IsaacLab-main/debug_notes.md，然后继续执行里面的 Next Steps，优先排查 HAPPO leader 不动的问题。每次回复结束前把新的关键结论更新回这个 md 文件。
```
